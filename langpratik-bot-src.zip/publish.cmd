nuget restore
msbuild QnABotWithMSI.sln -p:DeployOnBuild=true -p:PublishProfile=.\langpratik-bot-dc90-Web-Deploy.pubxml -p:Password=npmJLiGSgS32rpsfCF8NbDNy92t7MMfeHAmG6pLrjlkrpk18rb4ufA27o7qq

